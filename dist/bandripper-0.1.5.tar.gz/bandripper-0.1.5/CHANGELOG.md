# Changelog

## 0.1.4 (2023-03-31)

#### Refactorings

* change timer.current_elapsed_time() calls to timer.elapsed_str


## v0.1.3 (2023-03-22)

#### Fixes

* fix not passing cli switch to constructors
#### Others

* build v0.1.3
* update changelog


## v0.1.2 (2023-03-22)

#### Others

* build v0.1.2


## v0.1.1 (2023-03-22)

#### Fixes

* strip trailing spaces from track titles.
#### Others

* build v0.1.1
* update changelog


## v0.1.0 (2023-03-22)

#### New Features

* add param to control overwriting existing files.
#### Others

* build v0.1.0
* update changelog
* update with added param


## v0.0.0 (2023-03-22)

#### Others

* build v0.0.0
* add keywords to pyproject